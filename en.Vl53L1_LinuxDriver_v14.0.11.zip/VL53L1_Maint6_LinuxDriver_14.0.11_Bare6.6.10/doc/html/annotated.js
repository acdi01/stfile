var annotated =
[
    [ "stmvl53l1_autonomous_config_t", "structstmvl53l1__autonomous__config__t.html", "structstmvl53l1__autonomous__config__t" ],
    [ "stmvl53l1_ioctl_calibration_data_t", "structstmvl53l1__ioctl__calibration__data__t.html", "structstmvl53l1__ioctl__calibration__data__t" ],
    [ "stmvl53l1_ioctl_perform_calibration_t", "structstmvl53l1__ioctl__perform__calibration__t.html", "structstmvl53l1__ioctl__perform__calibration__t" ],
    [ "stmvl53l1_ioctl_zone_calibration_data_t", "structstmvl53l1__ioctl__zone__calibration__data__t.html", "structstmvl53l1__ioctl__zone__calibration__data__t" ],
    [ "stmvl53l1_module_fn_t", "structstmvl53l1__module__fn__t.html", "structstmvl53l1__module__fn__t" ],
    [ "stmvl53l1_parameter", "structstmvl53l1__parameter.html", "structstmvl53l1__parameter" ],
    [ "stmvl53l1_roi_full_t", "structstmvl53l1__roi__full__t.html", "structstmvl53l1__roi__full__t" ],
    [ "stmvl53l1_roi_t", "structstmvl53l1__roi__t.html", "structstmvl53l1__roi__t" ]
];