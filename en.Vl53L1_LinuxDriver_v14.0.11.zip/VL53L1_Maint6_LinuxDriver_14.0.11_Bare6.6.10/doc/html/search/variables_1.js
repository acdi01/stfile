var searchData=
[
  ['data',['data',['../structstmvl53l1__ioctl__calibration__data__t.html#a93b4bb56511fab5391ff96e34785a4ab',1,'stmvl53l1_ioctl_calibration_data_t::data()'],['../structstmvl53l1__ioctl__zone__calibration__data__t.html#ac4c80e7e018a15821b1eb0aa7a861508',1,'stmvl53l1_ioctl_zone_calibration_data_t::data()']]],
  ['deinit',['deinit',['../structstmvl53l1__module__fn__t.html#a1cde6458443e3c1fb6e4ab9e890bc4d9',1,'stmvl53l1_module_fn_t']]]
];
