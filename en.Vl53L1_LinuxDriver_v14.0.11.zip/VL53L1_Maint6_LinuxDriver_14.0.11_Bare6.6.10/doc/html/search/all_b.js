var searchData=
[
  ['xfer_5fid',['xfer_id',['../structipp__work__t.html#a1bf7b27b521c51c5ff85088e8ba6d4c4',1,'ipp_work_t']]]
];
