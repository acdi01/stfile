var searchData=
[
  ['numberofroi',['NumberOfRoi',['../structstmvl53l1__roi__t_1_1roi__cfg__t.html#a8a1b63e4a24156ded9dd71e1cb9a48a1',1,'stmvl53l1_roi_t::roi_cfg_t']]]
];
