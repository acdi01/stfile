var searchData=
[
  ['roi_5fcfg',['roi_cfg',['../structstmvl53l1__roi__t.html#aeab9564967685309f04bd536e1deb2fa',1,'stmvl53l1_roi_t::roi_cfg()'],['../structstmvl53l1__roi__full__t.html#a821d8c3c0d1aaea9fd2f86135c6bf4cb',1,'stmvl53l1_roi_full_t::roi_cfg()']]],
  ['roi_5fcfg_5ft',['roi_cfg_t',['../structstmvl53l1__roi__t_1_1roi__cfg__t.html',1,'stmvl53l1_roi_t']]]
];
