var structstmvl53l1__parameter =
[
    [ "is_read", "structstmvl53l1__parameter.html#a03c68d9cc944e659cb6800a95fec0454", null ],
    [ "status", "structstmvl53l1__parameter.html#a7fdeb23c7a9b1c7fec4e03af7a296e0f", null ],
    [ "value", "structstmvl53l1__parameter.html#a51312d39b8b78df21c32a8ecf016a942", null ],
    [ "value2", "structstmvl53l1__parameter.html#a5355ef762791b26fb4b4b569b9a3bb4f", null ]
];