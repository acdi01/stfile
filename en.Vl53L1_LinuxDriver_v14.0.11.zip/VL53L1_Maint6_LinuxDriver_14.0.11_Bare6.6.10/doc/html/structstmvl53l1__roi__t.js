var structstmvl53l1__roi__t =
[
    [ "is_read", "structstmvl53l1__roi__t.html#a964fc009ffe42607008c78e88da8774d", null ],
    [ "roi_cfg", "structstmvl53l1__roi__t.html#aeab9564967685309f04bd536e1deb2fa", null ]
];