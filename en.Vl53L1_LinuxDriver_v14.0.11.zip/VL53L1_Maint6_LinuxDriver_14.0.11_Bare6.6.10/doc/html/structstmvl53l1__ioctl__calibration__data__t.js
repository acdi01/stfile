var structstmvl53l1__ioctl__calibration__data__t =
[
    [ "data", "structstmvl53l1__ioctl__calibration__data__t.html#a93b4bb56511fab5391ff96e34785a4ab", null ],
    [ "is_read", "structstmvl53l1__ioctl__calibration__data__t.html#ab02b8fd295aef275194dd5cd43c932ef", null ]
];